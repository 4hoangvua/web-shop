import React, { useState } from "react";
import Image from "../../../components/Image";
import Button from "../../../components/Button";
import styles from "./Item.module.scss";
import classnames from "classnames/bind";
import * as Actions from "../../../Actions";
import { useDispatch, useSelector } from "react-redux";
import Notification from "../../../components/Notification";

const cx = classnames.bind(styles);
const Item = ({ product }) => {
  const [number, setNumber] = useState(1);
  const [isShow, setIsShow] = useState(false);
  const [isData, setIsData] = useState();
  const dispatch = useDispatch();
  const { myCarts } = useSelector((state) => state.gioHang);
  const handleIncrease = () => {
    setNumber((preNumber) => preNumber + 1);
  };
  const handleDecrease = () => {
    setNumber((preNumber) => preNumber - 1);
  };
  const handleAddCart = () => {
    dispatch({ type: Actions.ADD_CART, data: { product, quantity: number } });
    setIsData({ type: "success", message: "Successfully !" });
    setIsShow(true);
  };

  const handleChange = (e) => {
    const re = /^[0-9\b]+$/;
    const { value } = e.target;
    if (value === "" || re.test(value)) {
      setNumber(Number(value));
    }
  };
  return (
    <div className={cx("c-item")}>
      <div className={cx("item")}>
        <Image src={product.image} alt={product.name} />
        <div className={cx("item-content")}>
          <h1>{product.name}</h1>
          <p>Price: ${product.price}</p>
          <Button disable={number <= 1 ? true : false} onClick={handleDecrease}>
            -
          </Button>
          <input onChange={handleChange} value={number} type="text" />
          <Button onClick={handleIncrease}>+</Button>
          <br />
          <br />
          <Button onClick={handleAddCart}>Add cart</Button>
        </div>
      </div>
      <Notification data={isData} isShow={isShow} setIsShow={setIsShow} />
    </div>
  );
};

export default Item;
