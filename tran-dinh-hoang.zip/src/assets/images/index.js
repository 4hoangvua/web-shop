const images = {
  product: {
    laptop1: require("../../assets/images/laptop1.jpg"),
  },
};
export default images;
