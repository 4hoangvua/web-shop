import classnames from "classnames/bind";
import styles from "./Default.module.scss";

import Header from "../../Header";
const cx = classnames.bind(styles);
function DefaultLayout({ children }) {
  return (
    <div className={cx("container")}>
      <Header />
      <div className={cx("c-content")}>{children}</div>
      <div className={cx("c-footer")}>Footer</div>
    </div>
  );
}

export default DefaultLayout;
