import { combineReducers } from "redux";
import productReducer from "./SanPham";
import orderReducer from "./DonHang";
import lineOrder from "./DongDonHang";
import myCartReducer from "./MyCart";
const reducer = combineReducers({
  sanPham: productReducer,
  donHang: orderReducer,
  dongDonHang: lineOrder,
  gioHang: myCartReducer,
});
export default reducer;
