import React from "react";
import "./style.scss";
const GlobalStyle = ({ children }) => {
  return <div>{children}</div>;
};

export default GlobalStyle;
